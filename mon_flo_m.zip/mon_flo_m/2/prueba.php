<?php 
	echo "\nMensaje de prueba de PHP para ejecutar por consola.\n"; 
	echo "\nCreado por Manuel Monterroso Flores.\n";
?>
